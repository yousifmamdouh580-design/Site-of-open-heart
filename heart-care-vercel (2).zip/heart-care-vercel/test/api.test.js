// اختبار محلي للواجهة البرمجية بدون إنترنت: node test/api.test.js
const assert = require('assert');
const store = new Map(), sets = new Map();
process.env.SECRET = 'test-secret-123'; process.env.OWNER_USER = 'owner'; process.env.OWNER_PASS = 'OwnerPass#1';
process.env.KV_REST_API_URL = 'http://kv.local'; process.env.KV_REST_API_TOKEN = 't';
let anth = null;
global.fetch = async (url, opt) => {           // Redis وهمي في الذاكرة
  if (String(url).includes('anthropic.com')) { anth = { url, opt, body: JSON.parse(opt.body) }; return { ok: true, status: 200, json: async () => ({ content: [{ type: 'text', text: 'رد تجريبي' }] }) }; }
  const [c, ...a] = JSON.parse(opt.body); let r = null;
  const S = (k) => sets.get(k) || sets.set(k, new Set()).get(k);
  switch (c) {
    case 'GET': r = store.has(a[0]) ? store.get(a[0]) : null; break;
    case 'SET': if (a[2] === 'NX' && store.has(a[0])) r = null; else { store.set(a[0], a[1]); r = 'OK'; } break;
    case 'DEL': r = 0; a.forEach((k) => { if (store.delete(k)) r++; }); break;
    case 'MGET': r = a.map((k) => store.has(k) ? store.get(k) : null); break;
    case 'SADD': S(a[0]).add(a[1]); r = 1; break;
    case 'SREM': S(a[0]).delete(a[1]); r = 1; break;
    case 'SMEMBERS': r = [...S(a[0])]; break;
    case 'INCR': store.set(a[0], String((+store.get(a[0]) || 0) + 1)); r = +store.get(a[0]); break;
    case 'EXPIRE': r = 1; break;
    default: return { json: async () => ({ error: 'unknown ' + c }) };
  }
  return { json: async () => ({ result: r }) };
};
const handler = require('../api/app.js');
async function call(a, body, token) {
  let out = {}; const req = { method: 'POST', url: '/api/app?a=' + a, body, headers: Object.assign({ 'x-forwarded-for': '1.1.1.' + Math.floor(Math.random() * 250) }, token ? { authorization: 'Bearer ' + token } : {}) };
  const res = { setHeader() {}, end(s) { out = JSON.parse(s); } };
  await handler(req, res); out.code = res.statusCode; return out;
}
(async () => {
  const prof = { name: 'محمد أحمد علي', phone: '٠١٠١٢٣٤٥٦٧٨', email: 'm@test.com', age: 55, surgeon: 'د. سمير', surgeryDate: '2026-11-10', hospitalMin: 25, password: 'secret12' };
  let r = await call('register', prof); assert.strictEqual(r.code, 200, JSON.stringify(r)); const pt = r.token; const pid = r.profile.id;
  assert.strictEqual(r.profile.phone, '01012345678'); assert.ok(!r.profile.hash);
  r = await call('register', prof); assert.strictEqual(r.code, 409);                        // رقم مكرر
  r = await call('register', Object.assign({}, prof, { phone: '01099999999', email: 'bad' })); assert.strictEqual(r.code, 400);
  r = await call('login', { phone: '01012345678', password: 'wrong' }); assert.strictEqual(r.code, 401);
  r = await call('login', { phone: '01012345678', password: 'secret12' }); assert.strictEqual(r.code, 200);
  r = await call('me', {}, 'garbage'); assert.strictEqual(r.code, 401);
  r = await call('me', {}, pt); assert.strictEqual(r.code, 200); assert.strictEqual(r.profile.name, prof.name);
  // الأدوية
  r = await call('save_lists', { meds: [{ a: 'وارفارين', b: '5 مجم', c: '8 م', s: '2026-11-01', d: ['2026-11-19'] }], appts: [{ a: '2026-12-01', b: 'القلب', c: '' }] }, pt); assert.strictEqual(r.code, 200);
  r = await call('save_lists', { meds: [{ a: '' }], appts: [] }, pt); assert.strictEqual(r.code, 400);
  // الأعراض والتنبيه
  r = await call('save_log', { temp: 37.2, pulse: 78, sym: ['tired'], wound: 'ok' }, pt); assert.deepStrictEqual(r.alerts, []);
  r = await call('save_log', { temp: 38.4, sym: ['sob'], wound: 'disch' }, pt);
  assert.deepStrictEqual(r.alerts.sort(), ['ارتفاع الحرارة', 'إفرازات من الجرح', 'ضيق في النفس'].sort());
  // الاستبيان: لا يفتح قبل يومين
  r = await call('survey', {}, pt); assert.strictEqual(r.eligible, false); assert.strictEqual(r.url, null);
  // صلاحيات: المريض لا يرى المرضى
  r = await call('patients', {}, pt); assert.strictEqual(r.code, 401);
  // طاقم العمل
  r = await call('staff_login', { username: 'owner', password: 'bad' }); assert.strictEqual(r.code, 401);
  r = await call('staff_login', { username: 'owner', password: 'OwnerPass#1' }); assert.strictEqual(r.role, 'owner'); const ot = r.token;
  r = await call('patients', {}, ot); assert.strictEqual(r.patients.length, 1); assert.strictEqual(r.patients[0].lastLog.alerts.length, 3);
  r = await call('warnings', { today: '2026-11-21', hour: 21 }, ot);
  assert.strictEqual(r.alerts.length, 1); assert.strictEqual(r.missed.length, 1); assert.ok(r.missed[0].items.some((x) => x.includes('أمس')));
  r = await call('ack', { id: pid }, ot); assert.strictEqual(r.code, 200);
  r = await call('warnings', { today: '2026-11-21', hour: 10 }, ot); assert.strictEqual(r.alerts.length, 0);
  // إدارة الأدمن للمالك فقط
  r = await call('add_admin', { username: 'nurse1', name: 'ممرضة', password: 'nursepass1' }, ot); assert.strictEqual(r.code, 200);
  r = await call('staff_login', { username: 'nurse1', password: 'nursepass1' }); assert.strictEqual(r.role, 'admin'); const at = r.token;
  r = await call('patients', {}, at); assert.strictEqual(r.code, 200);
  r = await call('add_admin', { username: 'x12', name: 'خخخ', password: 'xxxxxxxx' }, at); assert.strictEqual(r.code, 401);
  r = await call('delete_patient', { id: pid }, at); assert.strictEqual(r.code, 401);
  r = await call('admins', {}, ot); assert.strictEqual(r.admins.length, 1);
  r = await call('delete_admin', { username: 'nurse1' }, ot); assert.strictEqual(r.code, 200);
  r = await call('staff_login', { username: 'nurse1', password: 'nursepass1' }); assert.strictEqual(r.code, 401);
  // حذف مريض
  r = await call('delete_patient', { id: pid }, ot); assert.strictEqual(r.code, 200);
  r = await call('patients', {}, ot); assert.strictEqual(r.patients.length, 0);
  r = await call('login', { phone: '01012345678', password: 'secret12' }); assert.strictEqual(r.code, 401);
  r = await call('nope', {}); assert.strictEqual(r.code, 404);
  // المساعد الذكي
  delete process.env.ANTHROPIC_API_KEY;
  r = await call('chat', { messages: [{ role: 'user', content: 'مرحبا' }] }); assert.strictEqual(r.code, 503);
  process.env.ANTHROPIC_API_KEY = 'k';
  r = await call('register', Object.assign({}, prof, { phone: '01077777777' })); const t2 = r.token;
  await call('save_lists', { meds: [{ a: 'وارفارين', b: '5 مجم', c: '8 م', s: '2026-11-01', d: [] }], appts: [] }, t2);
  r = await call('chat', { messages: [{ role: 'user', content: 'ما أدويتي؟' }] }, t2);
  assert.strictEqual(r.code, 200); assert.strictEqual(r.reply, 'رد تجريبي'); assert.strictEqual(r.emergency, false);
  assert.ok(anth.body.system.includes('وارفارين'), 'سياق المريض يصل للنموذج');
  ['محمد أحمد', '01077777777', 'm@test.com'].forEach((x) => assert.ok(!anth.body.system.includes(x), 'لا بيانات تعريفية: ' + x));
  assert.ok(anth.body.system.includes('قسم: العناية بالجرح'), 'معلومات الحقيبة موجودة');
  assert.strictEqual(anth.opt.headers['x-api-key'], 'k');
  r = await call('chat', { messages: [{ role: 'user', content: 'عندي ألم في الصدر الآن' }] }); assert.strictEqual(r.emergency, true);
  assert.ok(!anth.body.system.includes('وارفارين'), 'الزائر بدون بيانات مريض');
  r = await call('chat', { messages: [{ role: 'user', content: 'أشعر بضيق في النفس' }] }); assert.strictEqual(r.emergency, true);
  r = await call('chat', { messages: [{ role: 'assistant', content: 'x' }] }); assert.strictEqual(r.code, 400);
  console.log('كل الاختبارات نجحت ✔');
})().catch((e) => { console.error('فشل الاختبار:', e); process.exit(1); });
