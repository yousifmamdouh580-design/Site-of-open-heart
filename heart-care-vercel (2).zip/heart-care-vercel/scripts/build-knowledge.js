// يبني api/knowledge.js (معلومات المساعد الذكي) من أقسام index.html
// التشغيل بعد أي تعديل على الأقسام:  node scripts/build-knowledge.js
const fs = require('fs'), vm = require('vm'), path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const m = html.match(/var S=\[[\s\S]*?\n\];/);
if (!m) throw new Error('لم أجد المصفوفة S في index.html');
const S = vm.runInNewContext('(function(){var V="";' + m[0] + ';return S})()');
const txt = (h) => h
  .replace(/<div id="[a-z0-9]+"><\/div>/g, '')
  .replace(/<h3[^>]*>/g, '\n## ').replace(/<li>/g, '- ')
  .replace(/<\/(li|p|h3|tr|div)>/g, '\n').replace(/<br\s*\/?>/g, '\n')
  .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
let out = 'معلومات الحقيبة (مأخوذة من الموقع):\n\n';
S.filter((s) => s.id !== 'account' && s.id !== 'settings').forEach((s) => { out += '# قسم: ' + s.t + '\n' + txt(s.b) + '\n\n'; });
out += `# معلومات عامة عن الموقع
- رقم الطوارئ والإسعاف: 123.
- طاقم عمل الصفحة: 01113467723 و 01155636682.
- حساب المريض: يسجّل المريض برقم التليفون وكلمة سر، ويحفظ فيه أدويته ومواعيده وتسجيل أعراضه اليومي. الزائر يتصفح الأقسام بدون حساب.
- تسجيل الأعراض اليومي: يختار المريض ما يشعر به ويدخل قراءاته. عند اختيار علامة خطر (ألم صدر مفاجئ، ضيق نفس، ارتفاع الحرارة، إفرازات من الجرح، خفقان) تظهر له رسالة فورية ويصل تنبيه لطاقم العمل. تُعد الحرارة 38 درجة فأكثر ارتفاعًا في الحرارة.
- جدول الأدوية: خانة "تم اليوم" لتأشير كل جرعة، ويُنبَّه طاقم العمل لو لم تُؤشَّر الجرعات.
- المتابعة بعد الخروج: مكالمة أو رسالة واتساب في الأيام 3 و7 و14 و30.
- استبيان مدى الاستفادة: يفتح للمريض المسجل بعد مرور يومين على إنشاء حسابه.
- بعض التفاصيل (مدة منع حمل الأوزان والقيادة، التعليمات الغذائية، الجرعات) يحددها بروتوكول وحدة القلب والطبيب المعالج، وهي غير مكتوبة في هذا الموقع.
`;
fs.writeFileSync(path.join(root, 'api', 'knowledge.js'), 'module.exports = ' + JSON.stringify(out) + ';\n');
console.log('تم بناء api/knowledge.js (' + out.length + ' حرف)');
